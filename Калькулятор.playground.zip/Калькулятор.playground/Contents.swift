import UIKit

func calculator() {
  let a = Int(readLine()!)! //First input
  let b = Int(readLine()!)! //Second input
  
add(n1: a, n2: b)
subtract(n1: a, n2: b)
multiply(n1: a, n2: b)
divide(n1: a, n2: b)
  
}

func
